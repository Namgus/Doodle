/******************************************************************
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.

File Name: Assignment2.cpp
Author: <provide your English name >
Creation date: <date on which you created this file>
******************************************************************/

#include <iostream>
#include <string>

using namespace std;

// Do  NOT use hardcoded numbers for any ascii numbers use the character values
// Dont' worry about hex or binary strings, all strings can be decimal
// For this assignment assume the integers are positive
// Do not use atoi or itoa (the point of this is to do it yourself)
// Notice in the main function how I output the " with \" (the \ is called an escape character which tells the 
// compiler to to use the " as a character and not the start or end of a string (like say the " in "hello world")


// This takes a numeric string like "151" and returns the integer 151
int AtoI(std::string ascii) {
}

// Verify String tests the characters of the string to make sure each character is the ascii value of a number
// If you need a help on this function assignment 1 has a VerifyBinString function which is similar (but not the same)
// the function should either return true or return false
bool VerifyString(std::string ascii) {
}

// This takes an integer like 151 and return the numeric string like "151"
std::string ItoA(int number) {
}

int main() {
	int algo = 0;

	cout << "Enter Algorithm to run" << endl;
	cout << "1 to Convert string to int (atoi)" << endl;
	cout << "2 to Convert int to string (itoa)" << endl;

	cin >> algo;
#ifndef _MSC_VER
	cout << std::endl;
#endif

	string numberString;
	int number;
	switch (algo) {
	case 1:
		cout << "Enter the numeric string to convert: ";
		cin >> numberString;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (VerifyString(numberString) == true) {
			cout << '\"' << numberString << '\"' << " to integer = " << AtoI(numberString) << endl;
		}
		else {
			cout << '\"' << numberString << '\"' << " is not valid" << endl;
		}
		break;
	case 2:
		cout << "Enter the integer to convert: ";
		cin >> number;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			cout << number << " to a string = \"" << ItoA(number) << '\"' << endl;
		}
		else {
			cout << "Error in the input" << endl;
		}
		break;
	}
}