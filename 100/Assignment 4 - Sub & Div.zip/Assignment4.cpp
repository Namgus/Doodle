/******************************************************************
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.

File Name: Assignment4.cpp
Author: <provide your English name >
Creation date: <date on which you created this file>
******************************************************************/
#include <iostream>

using namespace std;

// You are to implement ALUSubtract, ALUDivide, and a function Negate without using operators +, *, -, /
// You may only use operators xor(^), and(&), or(|), bitflip(~), testing operators (==, !=, <, >),
// and assignment operators (=, &=, |=, ^=, <<=, >>=)
//
// You should copy your ALUAdd function from Assignment 3 into this file and use it for ALUSubtract and ALUDivide
// The Negate function takes a unsigned number and returns the negative version, so 2 returns 2s complement of 2 (which would be -2)
// The return value for ALUAdd is a signed int, which allows us to return a negative number and allows it to display correctly
//
// For division, don't worry about checking for the shift trick (just do the "brute force" method (count the number of subtractions)).   
// In other words use the same method when doing 15 / 2 as you would with 15 / 3 (use the method we discussed in class)
// Having a negative dividend or divisor will also cause problems, don't worry about that at this time
//
// A divide or mod by 0 are going to have problems (think about the logic and what would happen)
// write an error message saying "Divide by 0!" if the user tries to do that and return a 0

int ALUAdd(unsigned int decimal1, unsigned int decimal2) {
}

unsigned int Negate(unsigned int decimal) {
}

int ALUSubtract(unsigned int decimal1, unsigned int decimal2) {
}

unsigned int ALUDivide(unsigned int decimal1, unsigned int decimal2) {
}

unsigned int ALUMod(unsigned int decimal1, unsigned int decimal2) {
}

int main() {
	int algo = 0;

	cout << "Enter Algorithm to run" << endl;
	cout << "1 to Subtract 2 decimals" << endl;
	cout << "2 to Divide 2 decimals" << endl;
	cout << "3 to find the modulus of 2 decimals" << endl;

	cin >> algo;
#ifndef _MSC_VER
	cout << std::endl;
#endif

	unsigned int decimal1;
	unsigned int decimal2;
	switch (algo) {
	case 1:
		cout << "Enter the first decimal to subtract: ";
		cin >> decimal1;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		cout << "Enter the second decimal to subtract: ";
		cin >> decimal2;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			cout << decimal1 << " - " << decimal2 << " = " << ALUSubtract(decimal1, decimal2) << endl;
		}
		break;
	case 2:
		cout << "Enter the first decimal to divide (the dividend): ";
		cin >> decimal1;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		cout << "Enter the second decimal to divide (the divisor): ";
		cin >> decimal2;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			unsigned int result = ALUDivide(decimal1, decimal2);
			cout << decimal1 << " / " << decimal2 << " = " << result << endl;
		}
		break;
	case 3:
		cout << "Enter the first decimal (the dividend): ";
		cin >> decimal1;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		cout << "Enter the second decimal to divide (the divisor): ";
		cin >> decimal2;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			unsigned int result = ALUMod(decimal1, decimal2);
			cout << decimal1 << " % " << decimal2 << " = " << result  << endl;
		}
		break;
	}
}
