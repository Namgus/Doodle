/******************************************************************
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.

File Name: Assignment3.cpp
Author: <provide your English name >
Creation date: <date on which you created this file>
******************************************************************/
#include <iostream>

using namespace std;

// You are to implement ALUAdd & ALUMultiply without using operators add and multiply and subtract
// You may only use bitwise operators xor(^), and(&), or(|), shift(<<, >>), bool operators (==, !=, <, >, <=, >=),
// and assignment operators (=, &=, |=, ^=, <<=, >>=)

int ALUAdd(unsigned int decimal1, unsigned int decimal2) {
}

// Make sure you use ALUAdd so you don't duplicate code
// And again, no operators other than the bitwise, boolean and assignment
int ALUMultiply(unsigned int decimal1, unsigned int decimal2) {
}

int main() {
	int algo = 0;

	cout << "Enter Algorithm to run" << endl;
	cout << "1 to Add 2 decimals together" << endl;
	cout << "2 to Multiply 2 decimals together" << endl << endl;

	cin >> algo;

	unsigned int decimal1;
	unsigned int decimal2;
	switch (algo) {
	case 1:
		cout << "Enter the first decimal to add: ";
		cin >> decimal1;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		cout << "Enter the second decimal to add: ";
		cin >> decimal2;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			cout << decimal1 << " + " << decimal2 << " = " << ALUAdd(decimal1, decimal2) << endl;
		}
		break;
	case 2:
		cout << "Enter the first decimal to multiply: ";
		cin >> decimal1;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		cout << "Enter the second decimal to multiply: ";
		cin >> decimal2;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			cout << decimal1 << " * " << decimal2 << " = " << ALUMultiply(decimal1, decimal2) << endl;
		}
		break;
	}
}