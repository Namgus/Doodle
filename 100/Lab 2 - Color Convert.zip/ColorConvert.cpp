/******************************************************************
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.

File Name: ColorConvert.cpp
Author: <provide your English name >
Creation date: <date on which you created this file>
******************************************************************/
#include <iostream>

using namespace std;

// You are to implement code to convert from a 24 bit color into RGB, 16 bit into RGB and 24 bit to 16 bit
// Use the 16 bit format discussed in class (5/5/5)
// Use bit operations to do bit things (don't use + when you should be useing |)
//
// Replace the X with your answers
// A Good score has the hardcoded mask values
// An Excellent score uses math to create the masks, hint you may need to use sizeof() which returns the number of bytes of the data type or variable 
// Use the mask and shift values to get the color calculations, this information is all in the color lecture 
//
// If the color value & invalid masks is anything other than 0, it means some bits are left over and therefore the color is invalid
// Example: color16 = 0x8000 is invalid, as is 0xFFFF.  Using the invalid mask we can find if the MSB is set
// color24 = 0xFF000000 is invalid as is 0xFFFFFFFF and 0x01000000.  Using the invalid mask we can find if any bits in the high byte is set

unsigned short constexpr BLUE16_SHIFT = X;
unsigned short constexpr GREEN16_SHIFT = X;
unsigned short constexpr RED16_SHIFT = X;
unsigned short constexpr BLUE16_MASK = X;
unsigned short constexpr GREEN16_MASK = X;
unsigned short constexpr RED16_MASK = X;
unsigned short constexpr INVALID16_MASK = X;

unsigned int constexpr RED24_SHIFT = X;
unsigned int constexpr GREEN24_SHIFT = X;
unsigned int constexpr BLUE24_SHIFT = X;
unsigned int constexpr RED24_MASK = X;
unsigned int constexpr GREEN24_MASK = X;
unsigned int constexpr BLUE24_MASK = X;
unsigned int constexpr INVALID24_MASK = X;

unsigned int constexpr SHIFT_CONVERT_1632 = X;

void Convert24ToRGB(unsigned int color) {
	unsigned int red = X;
	unsigned int green = X;
	unsigned int blue = X;

	cout << "RGB = (" << red << ", " << green << ", " << blue << ")";
}

void Convert16ToRGB(unsigned short color) {
	unsigned int red = X;
	unsigned int green = X;
	unsigned int blue = X;

	cout << "RGB = (" << red << ", " << green << ", " << blue << ")";
}


void Convert24To16(unsigned int color) {
	unsigned int red = X;
	unsigned int green = X;
	unsigned int blue = X;

	unsigned int red16 = X;
	unsigned int green16 = X;
	unsigned int blue16 = X;

	unsigned short color16 = X;

	cout << "16-bit Color = 0x" << hex << color16;
}

bool Is24BitColorValid(unsigned int color) {
	if (X != 0) {
		return false;
	}
	return true;
}

bool Is16BitColorValid(unsigned short color) {
	if (X != 0) {
		return false;
	}
	return true;
}


int main() {

	int algo = 0;

	cout << "Enter Algorithm to run" << endl;
	cout << "1 to Convert 24 bit color to RGB" << endl;
	cout << "2 to Convert 16 bit color to RGB" << endl;
	cout << "3 to Convert 24 bit color to 16 bit color" << endl;

	cin >> algo;
#ifndef _MSC_VER
	cout << std::endl;
#endif

	int color;
	switch (algo) {
	case 1:
		cout << "Enter the 24 bit color: 0x";
		cin >> hex >> color;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			if (Is24BitColorValid(color) == true) {
				Convert24ToRGB(color);
			}
			else {
				cout << "24 Bit Color is not valid";
			}
		}
		break;
	case 2:
		cout << "Enter the 16 bit color: 0x";
		cin >> hex >> color;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			if (Is16BitColorValid(color) == true) {
				Convert16ToRGB(color);
			}
			else {
				cout << "16 Bit Color is not valid";
			}
		}
		break;
	case 3:
		cout << "Enter the 24 bit color: 0x";
		cin >> hex >> color;
#ifndef _MSC_VER
		cout << std::endl;
#endif
		if (cin.fail() == false) {
			if (Is24BitColorValid(color) == true) {
				Convert24To16(color);
			}
			else {
				cout << "24 Bit Color is not valid";
			}
		}
		break;
	}
#ifdef _MSC_VER
	system("pause");
#endif
}