// Name       : Jaehyeon Nam
// Assignment : simple level editor
// Course     : CS120
// Term & Year: Fall 2020

#include "Error.h"
#include "Level.h"
#include "LevelDrawing.h"
#include "LevelIO.h"
#include "condole_helper.h"


#include <doodle/doodle.hpp>
#include <filesystem>
#include <fstream>
#include <iostream>

using namespace doodle;

namespace
{
    const std::filesystem::path CACHE_FILEPATH{"cache.txt"};

    std::filesystem::path gLevelFilepath{"level.txt"};
    Level                 gLevel{};
    LevelTile             gTileMode = LevelTile::Background;

    Level load_a_level();
    void  write_level(const Level& level, const std::filesystem::path& path);
    Level read_level(const std::filesystem::path& path);
    void  mark_level(Level& level, LevelTile tile, int mouse_x, int mouse_y);
    void  clear_cache_file();
}


int main(void)
try
{
    gLevel = load_a_level();
    std::cout
        << "Press the SpaceBar => Background, 1 => Wall, 2 => Plant, or 3 => Spike keys to change the writing mode.\n"
        << "Press S to save your work.\n"
        << "Press N to start/open a new level.\n";

    create_window(1024, 768);
    set_frame_of_reference(FrameOfReference::LeftHanded_OriginTopLeft);

    while (!is_window_closed())
    {
        update_window();
        const double tile_width  = static_cast<double>(Width) / gLevel.get_width();
        const double tile_height = static_cast<double>(Height) / gLevel.get_height();
        draw_level(gLevel, tile_width, tile_height);
        draw_cursor(get_color_from_tile(gTileMode), tile_width, tile_height);
    }
    return 0;
}
catch (std::exception& e)
{
    clear_cache_file();
    std::cerr << "Error: " << e.what() << "\n";
    keep_window_open();
    return -1;
}

void on_mouse_pressed([[maybe_unused]] MouseButtons button)
{
    mark_level(gLevel, gTileMode, get_mouse_x(), get_mouse_y());
}

void on_mouse_moved([[maybe_unused]] int mouse_x, [[maybe_unused]] int mouse_y)
{
    if (!MouseIsPressed)
        return;
    mark_level(gLevel, gTileMode, mouse_x, mouse_y);
}

void on_key_released(KeyboardButtons button)
{
    switch (button)
    {
        case KeyboardButtons::Space: gTileMode = LevelTile::Background; break;
        case KeyboardButtons::_1:
        case KeyboardButtons::NumPad_1: gTileMode = LevelTile::Wall; break;
        case KeyboardButtons::_2:
        case KeyboardButtons::NumPad_2: gTileMode = LevelTile::Plant; break;
        case KeyboardButtons::_3:
        case KeyboardButtons::NumPad_3: gTileMode = LevelTile::Spike; break;
        case KeyboardButtons::Escape:
            write_level(gLevel, gLevelFilepath);
            close_window();
            break;
        case KeyboardButtons::S:
            write_level(gLevel, gLevelFilepath);
            gLevel = read_level(gLevelFilepath);
            break;
        case KeyboardButtons::N:
            write_level(gLevel, gLevelFilepath);
            clear_cache_file();
            gLevel = load_a_level();
            break;
        default: break;
    }
}


namespace
{
    using namespace std;

    void mark_level(Level& level, LevelTile tile, int mouse_x, int mouse_y)
    {
        const double tile_width   = static_cast<double>(Width) / level.get_width();
        const double tile_height  = static_cast<double>(Height) / level.get_height();
        const int    mouse_tile_x = static_cast<int>(mouse_x / tile_width);
        const int    mouse_tile_y = static_cast<int>(mouse_y / tile_height);

        if (mouse_tile_x < 0 || mouse_tile_x >= level.get_width())
            return;
        if (mouse_tile_y < 0 || mouse_tile_y >= level.get_height())
            return;

        level.at(mouse_tile_x, mouse_tile_y) = tile;
    }

    void write_cache_file()
    {
        ofstream file_stream{CACHE_FILEPATH};
        file_stream << gLevelFilepath << '\n';
    }

    void clear_cache_file() { filesystem::remove(CACHE_FILEPATH); }

    bool got_previous_level_filepath()
    {
        if (filesystem::exists(CACHE_FILEPATH))
        {
            ifstream file_stream{CACHE_FILEPATH};
            if (!file_stream)
            {
                clear_cache_file();
                return false;
            }
            if (file_stream >> gLevelFilepath)
                return true;
            clear_cache_file();
        }
        return false;
    }

    Level load_a_level()
    {
        if (got_previous_level_filepath())
        {
            if (ifstream file_stream{gLevelFilepath}; file_stream)
            {
                file_stream.exceptions(file_stream.exceptions() | ios_base::badbit);
                Level level;
                if (file_stream >> level)
                    return level;
            }
            clear_cache_file();
        }

        cout << "Enter the name of the level file :\n";
        cin >> gLevelFilepath;
        write_cache_file();
        if (ifstream file_stream{gLevelFilepath}; filesystem::exists(gLevelFilepath) && file_stream)
        {
            file_stream.exceptions(file_stream.exceptions() | ios_base::badbit);
            Level level;
            if (file_stream >> level)
                return level;
        }
        const int width  = get_int(1, 100, "Desired Level Width ");
        const int height = get_int(1, 100, "Desired Level Height ");
        Level     level{width, height};
        return level;
    }

    void write_level(const Level& level, const std::filesystem::path& path)
    {
        
        ofstream file_stream("gLevelFilepath");
        if (!file_stream.is_open())
        {
            cout << "error" << endl;
        }
        else if (!file_stream == NULL) {
            exit(-1);
        }
        file_stream << level;
    }

    Level read_level(const std::filesystem::path& path)
    {
        Level level;
        ifstream file_stream("gLevelFilepath"); 
        if (!file_stream.is_open())
        {
            cout << "error" << endl;
        }
        else if (!file_stream == NULL) {
            exit(-1);
        }

        file_stream >> level;

        return level;
    }
}
