// Name       : Jaehyeon Nam
// Assignment : simple level editor
// Course     : CS120
// Term & Year: Fall 2020
#pragma once


#include <istream>
#include <ostream>

class Level;
enum class LevelTile;

std::ostream& operator<<(std::ostream& out_stream, const LevelTile& tile);
std::istream& operator>>(std::istream& in_stream, LevelTile& tile);

std::ifstream& operator>>(std::ofstream& input, const LevelTile);

// TODO Declare output operator for Level class

// TODO Declare input operator for Level class

