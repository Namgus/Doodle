// Name       : Jaehyeon Nam
// Assignment : simple level editor
// Course     : CS120
// Term & Year: Fall 2020
#include "LevelIO.h"
#include "Error.h"
#include "Level.h"
#include <fstream>

std::ostream& operator<<(std::ostream& out_stream, const LevelTile& tile)
{
    switch (tile)
    {
        case LevelTile::Background: out_stream << '.'; break;
        case LevelTile::Wall: out_stream << '#'; break;
        case LevelTile::Plant: out_stream << '%'; break;
        case LevelTile::Spike: out_stream << '^'; break;
        default: error(__FUNCTION__ " : Unknown values for tile!");
    }
    return out_stream;
}

std::istream& operator>>(std::istream& in_stream, LevelTile& tile)
{
    char c{};
    if (in_stream >> c)
    {
        switch (c)
        {
            case '.': tile = LevelTile::Background; break;
            case '#': tile = LevelTile::Wall; break;
            case '%': tile = LevelTile::Plant; break;
            case '^': tile = LevelTile::Spike; break;
            default: error(__FUNCTION__ " : Unknown character for level tile!"); break;
        }
    }
    return in_stream;
}

// TODO Define output operator for Level class
std::ofstream& operator << (std::ofstream& output, const LevelTile)
{
    output << Level;
    
}
// TODO Define input operator for Level class
std::ifstream& operator >> (std::ofstream& input, const LevelTile)
{
    input >> Level;
    
}
    // TODO validate width and height markers and throw an exception/error when they aren't correct
    // TODO validate that reading the int values for width & height are successful 
    // TODO validate all Level Tile reads and throw an exception/error when they aren't correct

