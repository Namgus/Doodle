// Name       : TODO
// Assignment : TODO
// Course     : TODO
// Term & Year: TODO
#include "to_grey.h"

#include <cmath>

namespace CS120
{
    // TODO implement to_grey
}